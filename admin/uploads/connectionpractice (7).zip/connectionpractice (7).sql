-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 01, 2017 at 07:30 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `connectionpractice`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_in_bill`
--

CREATE TABLE IF NOT EXISTS `add_in_bill` (
  `Id` int(30) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(5) NOT NULL,
  `Account_Number` int(10) NOT NULL,
  `Date` date NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Quantity` int(5) NOT NULL,
  `Price` int(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `add_in_bill`
--

INSERT INTO `add_in_bill` (`Id`, `Mess_Number`, `Account_Number`, `Date`, `Item_Code`, `Quantity`, `Price`) VALUES
(33, 4, 6625, '2017-05-03', 'Ice Cream', 2, 50),
(34, 4, 6625, '2017-04-03', 'Curd', 2, 30),
(35, 4, 6513, '2017-04-04', 'Ice Cream', 3, 75),
(36, 4, 6513, '2017-04-03', 'Curd', 1, 15),
(37, 4, 6512, '2017-04-02', 'Curd', 3, 45),
(38, 4, 6001, '2017-04-05', 'Ice Cream', 3, 75),
(53, 4, 6625, '2017-04-09', 'Ice Cream', 1, 25),
(52, 4, 6625, '2017-04-17', 'Ice Cream', 2, 50),
(51, 4, 2529, '2017-02-02', 'Ice Cream', 6, 150);

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE IF NOT EXISTS `bill` (
  `Mess_Number` int(10) NOT NULL,
  `Account_Number` int(10) NOT NULL,
  `Number_Of_Days_Closed` int(10) NOT NULL,
  `Guests` int(10) NOT NULL,
  `Rebate` int(10) NOT NULL,
  `Total_Bill` int(10) NOT NULL,
  `Amount_Due` int(10) NOT NULL,
  `Month` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--


-- --------------------------------------------------------

--
-- Table structure for table `bill_detail`
--

CREATE TABLE IF NOT EXISTS `bill_detail` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(10) NOT NULL,
  `Account_Number` int(10) NOT NULL,
  `Amount_Due` int(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `bill_detail`
--

INSERT INTO `bill_detail` (`Id`, `Mess_Number`, `Account_Number`, `Amount_Due`) VALUES
(1, 4, 6625, 3050),
(2, 1, 6513, 500),
(3, 2, 6512, 500),
(4, 4, 6566, 500),
(5, 3, 6001, 500),
(6, 4, 6002, 500);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `account_number` int(11) NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `uni_roll_number` int(11) NOT NULL,
  `class_roll_number` int(11) NOT NULL,
  `mobile_number` varchar(30) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `create_password` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(30) NOT NULL,
  `Mess_Number` int(11) NOT NULL,
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`account_number`, `full_name`, `father_name`, `branch`, `uni_roll_number`, `class_roll_number`, `mobile_number`, `email_id`, `create_password`, `dob`, `gender`, `Mess_Number`, `Id`) VALUES
(2529, 'Barinder Kaur', 'Sukhwinder Singh', 'CSE', 1410817, 145042, '9463869330', 'barindersaini009@gmail.com', 'Gndec123', '1996-01-04', 'Female', 4, 12),
(2508, 'Harkamaldeep Kaur', 'Paramjit Singh', 'CSE', 1410836, 145030, '8437669045', 'hcheema1997@gmail.com', 'Gndec123', '1997-01-14', 'Female', 4, 11),
(6513, 'Jaspreet Singh', 'Baljit Singh', 'CSE', 1410856, 145042, '7696298399', 'jasnandha973@gmail.com', 'Gndec123', '1994-10-06', 'Male', 4, 10),
(6625, 'Jagmeet Singh', 'Jagjit Singh', 'CSE', 1410849, 145036, '9876545924', 'jsbhatia123467@gmail.com', 'Gndec123', '1995-11-24', 'Male', 4, 13),
(2552, 'Jagmeet Kaur', 'Rashpal Singh', 'CSE', 1410848, 145037, '9888974433', 'jagmeetsohal93@yahoo.com', 'Gndec123', '1995-03-14', 'Female', 4, 14),
(6625, 'jagmeet', 'jagjeet singh', 'cse', 1410849, 145036, '9876545924', 'jsbhatia12367@gmail.com', 'jagubhatia', '0000-00-00', 'Male', 4, 16);

-- --------------------------------------------------------

--
-- Table structure for table `confirm_order`
--

CREATE TABLE IF NOT EXISTS `confirm_order` (
  `Mess_Number` int(11) NOT NULL,
  `Order_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Total_Price` int(11) NOT NULL,
  `Status` varchar(30) NOT NULL DEFAULT 'not received',
  `Date` date NOT NULL,
  PRIMARY KEY (`Order_Number`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `confirm_order`
--

INSERT INTO `confirm_order` (`Mess_Number`, `Order_Number`, `Total_Price`, `Status`, `Date`) VALUES
(4, 70, 20, 'not received', '0000-00-00'),
(4, 69, 40, 'received', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `diet_item`
--

CREATE TABLE IF NOT EXISTS `diet_item` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(11) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `diet_item`
--

INSERT INTO `diet_item` (`Id`, `Mess_Number`, `Category`, `Item_Code`, `Price`) VALUES
(25, 4, 'Breakfast', 'aloo parantha', 20);

-- --------------------------------------------------------

--
-- Table structure for table `extra_item`
--

CREATE TABLE IF NOT EXISTS `extra_item` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(11) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `extra_item`
--

INSERT INTO `extra_item` (`Id`, `Mess_Number`, `Item_Code`, `Price`) VALUES
(16, 4, 'Ice Cream', 25),
(17, 4, 'Curd', 15);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `Mess_Number` int(4) NOT NULL,
  `Account_Number` int(10) NOT NULL,
  `Feedback` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `inventory_item`
--

CREATE TABLE IF NOT EXISTS `inventory_item` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(11) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `inventory_item`
--

INSERT INTO `inventory_item` (`Id`, `Mess_Number`, `Category`, `Item_Code`, `Price`) VALUES
(7, 4, 'Vegetable', 'Bhindi', 10),
(3, 4, 'Vegetables', 'Aloo', 15),
(4, 4, 'Spices', 'Chana Masala', 50),
(5, 4, 'Dairy Products', 'Milk', 23),
(6, 4, 'Grocery', 'Sugar', 35),
(8, 4, 'Vegetable', 'Kheera', 10),
(9, 4, 'Spices', 'Kali Mirch', 40),
(10, 4, 'Spices', 'Zira', 30),
(11, 4, 'Dairy Products', 'Dahi', 15),
(12, 4, 'Dairy Products', 'Butter', 20),
(13, 4, 'Grocery', 'Kaale Chane', 50),
(14, 4, 'Grocery', 'Rajma', 40);

-- --------------------------------------------------------

--
-- Table structure for table `issue_order`
--

CREATE TABLE IF NOT EXISTS `issue_order` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Issue_Number` int(11) NOT NULL,
  `Mess_Number` int(11) NOT NULL,
  `Item_Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Stock_Left` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=96 ;

--
-- Dumping data for table `issue_order`
--

INSERT INTO `issue_order` (`Id`, `Issue_Number`, `Mess_Number`, `Item_Category`, `Item_Code`, `Quantity`, `Date`, `Time`, `Stock_Left`) VALUES
(95, 0, 0, 'Dairy', 'Curd', 13, '0000-00-00', '00:00:00', 53),
(94, 0, 0, 'Dairy', 'Curd', 10, '0000-00-00', '00:00:00', 66);

-- --------------------------------------------------------

--
-- Table structure for table `item_list`
--

CREATE TABLE IF NOT EXISTS `item_list` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(11) NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `item_list`
--

INSERT INTO `item_list` (`Id`, `Mess_Number`, `Category`, `Item_Code`, `Price`) VALUES
(1, 4, 'Spices', 'Hari Mirch', 200),
(2, 4, 'Vegetables', 'Bhindi', 20),
(3, 4, 'Dairy Products', 'Milk', 23),
(4, 4, 'Pulses', 'Moong Daal', 60),
(5, 4, 'Spices', 'Kali mirch', 30),
(6, 4, 'Spices', 'mirch', 20);

-- --------------------------------------------------------

--
-- Table structure for table `item_price`
--

CREATE TABLE IF NOT EXISTS `item_price` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(11) NOT NULL,
  `Item_Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `item_price`
--

INSERT INTO `item_price` (`Id`, `Mess_Number`, `Item_Category`, `Item_Code`, `Price`) VALUES
(31, 1, 'Dairy', 'Curd', 20),
(30, 1, 'Vegetables', 'Carrot', 20),
(28, 2, 'Dairy', 'Mik', 21),
(26, 2, 'Spices', 'Mirchi', 24);

-- --------------------------------------------------------

--
-- Table structure for table `messmenu`
--

CREATE TABLE IF NOT EXISTS `messmenu` (
  `Day` varchar(10) NOT NULL,
  `Breakfast` varchar(100) NOT NULL,
  `Lunch` varchar(100) NOT NULL,
  `Dinner` varchar(100) NOT NULL,
  `Mess_Number` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messmenu`
--

INSERT INTO `messmenu` (`Day`, `Breakfast`, `Lunch`, `Dinner`, `Mess_Number`) VALUES
('Monday', 'aloo parauntha', 'white chana', 'dal and aloo sabji', 4),
('Tuesday', 'onion parauntha', 'black channe', 'dal and panner bhurji', 4),
('Wednesday', 'paneer parauntha', 'aloo mutter', 'dal and nutri', 4),
('Thrusday', 'Pastri pattie', 'dal', 'mutter paneer', 4),
('Friday', 'bread roll', 'channa puri', 'saag', 4),
('Saturday', 'Paneer paruntha', 'rajma', 'palak paneer', 4),
('Sunday', 'bread butter', 'pulaw', 'gajar mutter aloo', 4);

-- --------------------------------------------------------

--
-- Table structure for table `new_order`
--

CREATE TABLE IF NOT EXISTS `new_order` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Order_Number` int(11) NOT NULL,
  `Mess_Number` int(11) NOT NULL,
  `Item_Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=129 ;

--
-- Dumping data for table `new_order`
--

INSERT INTO `new_order` (`Id`, `Order_Number`, `Mess_Number`, `Item_Category`, `Item_Code`, `Quantity`, `Date`, `Time`, `Price`) VALUES
(122, 59, 1, 'Vegetables', 'Carrot', 13, '0000-00-00', '00:00:00', 260),
(121, 58, 1, 'Vegetables', 'Curd', 1, '0000-00-00', '00:00:00', 20),
(120, 58, 1, 'Dairy', 'Curd', 1, '0000-00-00', '00:00:00', 20),
(123, 59, 1, 'Dairy', 'Curd', 15, '0000-00-00', '00:00:00', 300),
(124, 60, 1, 'Dairy', 'Curd', 1, '0000-00-00', '00:00:00', 20),
(125, 60, 1, 'Spices', 'Mirchi', 1, '0000-00-00', '00:00:00', 24),
(126, 69, 4, 'Dairy', 'Curd', 1, '0000-00-00', '00:00:00', 20),
(127, 69, 4, 'Vegetables', 'Carrot', 1, '0000-00-00', '00:00:00', 20),
(128, 70, 4, 'Dairy', 'Curd', 1, '0000-00-00', '00:00:00', 20);

-- --------------------------------------------------------

--
-- Table structure for table `open_close`
--

CREATE TABLE IF NOT EXISTS `open_close` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Account_Number` int(11) NOT NULL,
  `From_Date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `open_close`
--


-- --------------------------------------------------------

--
-- Table structure for table `open_close_main`
--

CREATE TABLE IF NOT EXISTS `open_close_main` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `Account_Number` int(10) NOT NULL,
  `From_Date` date NOT NULL,
  `To_Date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=136 ;

--
-- Dumping data for table `open_close_main`
--

INSERT INTO `open_close_main` (`Id`, `Account_Number`, `From_Date`, `To_Date`) VALUES
(135, 6513, '0000-00-00', '2017-04-17'),
(134, 6513, '2017-04-02', '0000-00-00'),
(133, 6625, '0000-00-00', '2017-04-17'),
(132, 6625, '2017-04-02', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `signupa`
--

CREATE TABLE IF NOT EXISTS `signupa` (
  `Mess_Number` int(11) NOT NULL,
  `Employee_Id` varchar(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Mobile_Number` varchar(20) NOT NULL,
  `Email_Id` varchar(40) NOT NULL,
  `Create_Password` varchar(30) NOT NULL,
  `Confirm_Password` varchar(30) NOT NULL,
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `signupa`
--

INSERT INTO `signupa` (`Mess_Number`, `Employee_Id`, `Name`, `Gender`, `Mobile_Number`, `Email_Id`, `Create_Password`, `Confirm_Password`, `Id`) VALUES
(4, '4', 'Barinder kaur', 'Female', '9463869330', 'barinder@gmail.com', 'Gndec123', 'Gndec123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `signupm`
--

CREATE TABLE IF NOT EXISTS `signupm` (
  `Mess_Number` int(11) NOT NULL,
  `Employee_Id` varchar(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Mobile_Number` varchar(20) NOT NULL,
  `Email_Id` varchar(40) NOT NULL,
  `Create_Password` varchar(30) NOT NULL,
  `Confirm_Password` varchar(30) NOT NULL,
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `signupm`
--

INSERT INTO `signupm` (`Mess_Number`, `Employee_Id`, `Name`, `Gender`, `Mobile_Number`, `Email_Id`, `Create_Password`, `Confirm_Password`, `Id`) VALUES
(4, '4', 'Barinder kaur', 'Female', '9463869330', 'barinder@gmail.com', 'Gndec123', 'Gndec123', 1),
(1, '1', 'Harkamaldeep kaur', 'Female', '8437669045', 'harkamal@gmail.com', 'Gndec123', 'Gndec123', 2),
(3, '3', 'Jagmeet kaur', 'Female', '9888974433', 'jagmeetkaur@gmail.com', 'Gndec123', 'Gndec123', 3),
(2, '2', 'Jagmeet singh', 'Male', '9876545924', 'jagmeet@gmail.com', 'Gndec123', 'Gndec123', 4),
(5, '5', 'Jaspreet singh', 'Male', '7696298399', 'jaspreet@gmail.com', 'Gndec123', 'Gndec123', 5);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Number` int(11) NOT NULL,
  `Item_Category` varchar(30) NOT NULL,
  `Item_Code` varchar(30) NOT NULL,
  `Quantity` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`Id`, `Mess_Number`, `Item_Category`, `Item_Code`, `Quantity`) VALUES
(26, 4, 'Dairy', 'Curd', 54),
(15, 4, 'Dairy', 'Milk', 42),
(14, 4, 'Vegetables', 'Carrot', 42),
(13, 4, 'Spices', 'Mirchi', 20),
(27, 4, 'Dairy', 'c', 0),
(20, 4, 'Spices', 'Mirchi', 30),
(21, 4, 'Vegetables', 'Carrot', 42),
(22, 4, 'Dairy', 'Milk', 23);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
